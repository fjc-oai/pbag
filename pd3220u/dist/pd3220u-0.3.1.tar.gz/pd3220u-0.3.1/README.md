Example package following python packaging tutorail https://packaging.python.org/en/latest/tutorials/packaging-projects/
