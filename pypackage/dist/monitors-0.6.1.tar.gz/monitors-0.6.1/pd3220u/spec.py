def print_spec():
    print('pd3220u: 32", 60hz, ips')
