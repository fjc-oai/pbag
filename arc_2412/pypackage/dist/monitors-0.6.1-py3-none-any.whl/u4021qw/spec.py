def print_spec():
    print('u4021qw: 40", 30hz, ips')
