def print_spec():
    print('u3223qe: 32", 60hz, ips')
